/*
 * vowel_cnt.h
 *
 * Created: 31-07-2024 12:54:29
 *  Author: PARVEZ KHAN
 */ 


#ifndef VOWEL_CNT_H_
#define VOWEL_CNT_H_


extern int vowel_count = 0 ;


#endif /* VOWEL_CNT_H_ */