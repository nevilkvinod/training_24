/*
 * IncFile1.h
 *
 * Created: 01-08-2024 11:45:13
 *  Author: PARVEZ KHAN
 */ 

// config.h
#ifndef CONFIG_H
#define CONFIG_H

extern int max_min;

#endif // CONFIG_H
