/*
 * CFile1.c
 *
 * Created: 01-08-2024 11:47:13
 *  Author: PARVEZ KHAN
 */ 
int max_min = 1;
