/*
 * GccLibrary1.c
 *
 * Created: 31-07-2024 12:50:39
 * Author : PARVEZ KHAN
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

