/*
 * matmul.c
 *
 * Created: 05-08-2024 14:04:09
 * Author : PARVEZ KHAN
 */ 

#include <avr/io.h>
#include <stdio.h>

int multiply_matrices(int *A[], int *B[], int rowsA, int colsA, int rowsB,int colsB, int *C[]) {
	
	if ((colsA != rowsA) && (colsB != rowsB)) {
		return 0;
	}

	for (int i = 0; i < rowsA; i++) {
		for (int j = 0; j < colsB; j++) {
			for (int k = 0; k < colsA; k++) {
				C[i][j] += A[i][k] * B[k][j];
			}
		}
	}

	return 1;
}

int main(void) {
	int possible=0;
	int notpossible=0;
	
	int A[3][3] = {{1, 2, 3},
	               {4, 5, 6},
	               {7, 8, 9}};
	
	int B[3][3] = {{1, 2, 3},
	               {4, 5, 6},
	               {7, 8, 9}};
	
	int C[3][3];


	int *ptrA[3], *ptrB[3], *ptrC[3];


	for (int i = 0; i < 3; i++) {
		ptrA[i] = A[i];
		ptrB[i] = B[i];
		ptrC[i] = C[i];
	}
	
	int k =multiply_matrices(ptrA, ptrB, 3, 3, 3, 3, ptrC);


	if (k != 0) {
				possible = 1;			
		}
		else {
		        notpossible = 1;
				
	}

	return 0;
}

